export {};
//# sourceMappingURL=myfirstts.d.ts.map