function greeting(name) {
    return 'Hello, {$name}';
}
;
const msg = greeting("Opash software!");
console.log(msg);
export {};
//# sourceMappingURL=myfirstts.js.map