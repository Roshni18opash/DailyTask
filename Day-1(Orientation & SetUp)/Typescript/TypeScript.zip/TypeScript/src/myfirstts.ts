function greeting (name:string):string{
    return 'Hello, {$name}'
};
const msg:string=greeting("Opash software!");
console.log(msg);
