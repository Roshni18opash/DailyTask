function greeting(name) {
    return 'Hello, {$name}';
}
;
var msg = greeting("Opash software!");
console.log(msg);
